/**
 * @file BoticShieldV1.h
 * @brief Motor control library for Botic Shield V1
 *
 * Hardware: L293D + 74HC595
 * Author:   Raunak Choudhary
 * Version:  1.2.0
 */

#ifndef BOTICSHIELDV1_H
#define BOTICSHIELDV1_H

#include <Arduino.h>

// ── Motion Bit Patterns ───────────────────────────────────────

// Basic motion
#define BOTIC_FORWARD        0b01100110
#define BOTIC_BACKWARD       0b10011001
#define BOTIC_LEFT           0b01000100
#define BOTIC_RIGHT          0b00100010
#define BOTIC_STOP           0b00000000

// Sharp turns (Tank Turn)
#define BOTIC_SHARP_LEFT     0b01011010
#define BOTIC_SHARP_RIGHT    0b10100101

// Advanced control
#define BOTIC_BRAKE          0b11111111
#define BOTIC_LEFT_FORWARD   0b01010000
#define BOTIC_RIGHT_FORWARD  0b00000101

// ─────────────────────────────────────────────────────────────

class BoticShieldV1 {
  public:

    BoticShieldV1(uint8_t dataPin  = 11,
                  uint8_t clockPin = 13,
                  uint8_t latchPin = 10,
                  uint8_t en1Pin   = 3,
                  uint8_t en2Pin   = 6);

    void begin(uint8_t speed = 200);

    void setSpeed(uint8_t speed);
    uint8_t getSpeed() const;

    // Basic motion
    void forward();
    void backward();
    void left();
    void right();
    void stop();

    // Sharp turns
    void sharpLeft();
    void sharpRight();

    // Advanced control
    void brake();
    void leftForward();
    void rightForward();

    // Timed movement
    void moveFor(char direction, unsigned long ms);

    // Raw control
    void sendRaw(uint8_t data);

  private:
    uint8_t _data, _clock, _latch;
    uint8_t _en1, _en2;
    uint8_t _speed;

    void _shiftSend(uint8_t data);
};

#endif