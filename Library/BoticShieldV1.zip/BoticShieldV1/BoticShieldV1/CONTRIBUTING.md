# 🤝 Contributing to BoticShieldV1

Thank you for considering contributing to the **BoticShieldV1** library!  
Every contribution — bug fixes, new examples, documentation improvements, or board support — is valued.

---

## 📋 Ways to Contribute

- 🐛 **Report a Bug** — Open an [Issue](https://github.com/raunakchoudhary/BoticShieldV1/issues)
- 💡 **Suggest a Feature** — Open an [Issue](https://github.com/raunakchoudhary/BoticShieldV1/issues) with the `enhancement` label
- 📖 **Improve Documentation** — Fix typos, improve wording, add diagrams
- 🧪 **Add Examples** — Write new `.ino` example sketches
- 🔧 **Fix Bugs** — Submit a Pull Request

---

## 🚀 Getting Started

### 1. Fork the Repository

Click **Fork** at the top right of the repo page.

### 2. Clone Your Fork

```bash
git clone https://github.com/<your-username>/BoticShieldV1.git
cd BoticShieldV1
```

### 3. Create a Feature Branch

```bash
git checkout -b feature/my-new-feature
# or
git checkout -b fix/bug-description
```

### 4. Make Your Changes

- Follow the code style used in existing files
- Comment your code clearly
- Test on real hardware if possible

### 5. Commit Your Changes

Use clear, descriptive commit messages:

```bash
git commit -m "feat: add IR remote control example"
git commit -m "fix: correct motor 3 direction bit pattern"
git commit -m "docs: add ESP32 wiring notes to README"
```

### 6. Push and Open a Pull Request

```bash
git push origin feature/my-new-feature
```

Go to GitHub → Open Pull Request → Describe your changes clearly.

---

## 📐 Code Style Guide

- Use **2-space indentation** (Arduino style)
- Use `camelCase` for function names and variables
- Use `UPPER_CASE` for `#define` constants
- Add a `@brief` comment above every public method
- Keep examples simple and well-commented

---

## 🧪 Testing Checklist (Before PR)

- [ ] Code compiles without errors on Arduino UNO
- [ ] New functions have documentation in the `.h` file
- [ ] Example sketches are in their own folder under `examples/`
- [ ] README updated if new features were added
- [ ] `keywords.txt` updated if new methods added
- [ ] `library.properties` version bumped if significant change

---

## 🐛 Reporting Bugs

When opening a bug report issue, please include:

1. **Arduino board** (UNO, Nano, Mega…)
2. **Arduino IDE version**
3. **Library version** (`v1.0.0`)
4. **What you expected** to happen
5. **What actually happened**
6. **Minimal code** that reproduces the issue

---

## 💬 Questions?

Open a [GitHub Discussion](https://github.com/raunakchoudhary/BoticShieldV1/discussions) or an Issue with the `question` label.

---

*Thank you for making BoticShieldV1 better!* 🤖
