# 📋 Changelog

All notable changes to **BoticShieldV1** will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),  
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] — 2025-01-01

### 🎉 Initial Release

#### Added
- `BoticShieldV1` class with default pin constructor
- `begin(speed)` — initialise pins and set PWM speed safely
- `setSpeed(speed)` — change motor speed at runtime (0–255)
- `getSpeed()` — return current speed value
- `forward()` — all 4 motors forward
- `backward()` — all 4 motors reverse
- `left()` — pivot left (right side drives, left coasts)
- `right()` — pivot right (left side drives, right coasts)
- `stop()` — cut all motor output
- `moveFor(direction, ms)` — timed movement with automatic stop
- `sendRaw(byte)` — direct 74HC595 shift register access
- Named constants: `BOTIC_FORWARD`, `BOTIC_BACKWARD`, `BOTIC_LEFT`, `BOTIC_RIGHT`, `BOTIC_STOP`
- Example: `BasicControl` — simple timed move sequence
- Example: `BluetoothControl` — HC-05/HC-06 serial command interface
- Example: `SpeedTest` — PWM ramp 0 → 255 → 0
- Full API documentation via Doxygen-style comments in header
- `README.md` with wiring diagrams, API reference, troubleshooting
- `CONTRIBUTING.md` with PR guidelines
- `keywords.txt` for Arduino IDE syntax highlighting
- `library.properties` for Arduino Library Manager

---

## [Unreleased]

### Planned
- Non-blocking `moveFor()` using `millis()`
- Individual motor control methods (`setMotor(id, direction)`)
- ESP32 / ESP8266 verified compatibility
- PlatformIO `platformio.ini` config
- GitHub Actions CI for compile check

---

*Maintained by Raunak Choudhary*
